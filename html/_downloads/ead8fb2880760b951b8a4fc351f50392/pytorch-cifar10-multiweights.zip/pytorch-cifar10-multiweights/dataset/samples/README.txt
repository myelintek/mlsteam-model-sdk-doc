These sample images are retrieved from the following Cifar10 dataset through torchvision:
Learning Multiple Layers of Features from Tiny Images, Alex Krizhevsky, 2009.
