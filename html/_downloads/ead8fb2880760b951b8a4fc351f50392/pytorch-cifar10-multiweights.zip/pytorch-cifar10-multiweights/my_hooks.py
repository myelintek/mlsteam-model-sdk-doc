import torch
from mlsteam_model_sdk.sdk.helper.loader.torch import Loader

from .train_multi_weights import Net, classes


def load_model(env, submodels, model_file_loader, *args, **kwargs):
    subm_name = 'main'
    model_obj = Loader.from_submodel(model_obj=Net(),
                                     model_file_loader=model_file_loader,
                                     subm_name=subm_name)
    return {subm_name: model_obj}


def classify(env, model, inputs, service_name=None, *args, **kwargs):
    svc_name = 'classify'
    if not service_name or service_name == svc_name:
        main_model = model['main']
        outputs = main_model(inputs)
        _, predicted = torch.max(outputs, 1)
        return predicted, [classes[p] for p in predicted]
    raise ValueError(f'Invalid service name: {service_name}')
