from mlsteam_model_sdk.sdk.helper.loader.torch import Loader

from ..src.train_multi_weights import Net


def load(env, submodels, model_file_loader, *args, **kwargs):
    subm_name = 'main'
    model_obj = Loader.from_submodel(model_obj=Net(),
                                     model_file_loader=model_file_loader,
                                     subm_name=subm_name)
    return {subm_name: model_obj}
