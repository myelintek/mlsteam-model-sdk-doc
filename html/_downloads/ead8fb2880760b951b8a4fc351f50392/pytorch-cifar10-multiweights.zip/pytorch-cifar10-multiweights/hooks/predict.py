import torch

from ..src.train_multi_weights import classes


def predict(env, model, inputs, service_name=None, *args, **kwargs):
    svc_name = 'classify'
    if not service_name or service_name == svc_name:
        main_model = model['main']
        outputs = main_model(inputs)
        _, predicted = torch.max(outputs, 1)
        return predicted, [classes[p] for p in predicted]
    raise ValueError(f'Invalid service name: {service_name}')
