"""PyTorch Example: multiple weight files

Ref: [Training a Classifier](https://pytorch.org/tutorials/beginner/blitz/cifar10_tutorial.html)
"""
import argparse
import itertools
import pathlib
from collections import OrderedDict

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms


classes = ('plane', 'car', 'bird', 'cat',
           'deer', 'dog', 'frog', 'horse', 'ship', 'truck')


def get_ds_dir(sample_ds=False, create_dir=False) -> pathlib.Path:
    ds_dir = pathlib.Path(__file__).parent / 'dataset' / ('cifar10' if not sample_ds else 'samples')
    if create_dir:
        ds_dir.mkdir(parents=True, exist_ok=True)
    return ds_dir


def get_ds():
    transform = transforms.Compose(
        [transforms.ToTensor(),
         transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])

    batch_size = 4
    ds_dir = get_ds_dir(create_dir=True)

    trainset = torchvision.datasets.CIFAR10(root=ds_dir, train=True, download=True, transform=transform)
    trainloader = torch.utils.data.DataLoader(trainset, batch_size=batch_size, shuffle=True, num_workers=2)

    testset = torchvision.datasets.CIFAR10(root=ds_dir, train=False, download=False, transform=transform)
    testloader = torch.utils.data.DataLoader(testset, batch_size=batch_size, shuffle=False, num_workers=2)

    return trainloader, testloader, classes


class Net(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(3, 6, 5)
        self.pool = nn.MaxPool2d(2, 2)
        self.conv2 = nn.Conv2d(6, 16, 5)
        self.fc1 = nn.Linear(16 * 5 * 5, 120)
        self.fc2 = nn.Linear(120, 84)
        self.fc3 = nn.Linear(84, 10)

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = torch.flatten(x, 1)  # flatten all dimensions except batch
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return x


def train(trainloader):
    net = Net()
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(net.parameters(), lr=0.001, momentum=0.9)

    for epoch in range(2):  # loop over the dataset multiple times
        running_loss = 0.0
        for i, data in enumerate(trainloader, 0):
            # get the inputs; data is a list of [inputs, labels]
            inputs, labels = data

            # zero the parameter gradients
            optimizer.zero_grad()

            # forward + backward + optimize
            outputs = net(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            # print statistics
            running_loss += loss.item()
            if i % 2000 == 1999:    # print every 2000 mini-batches
                print(f'[{epoch + 1}, {i + 1:5d}] loss: {running_loss / 2000:.3f}')
                running_loss = 0.0

    print('Finished Training')
    return net


def get_model_dir(create_dir=False) -> pathlib.Path:
    model_dir = pathlib.Path(__file__).parent / 'model'
    if create_dir:
        model_dir.mkdir(parents=True, exist_ok=True)
    return model_dir


def save_model(model):
    model_dir = get_model_dir(create_dir=True)
    state_items = model.state_dict().items()
    with (model_dir / 'cifar_model-1.pth').open('wb') as model_fp:
        sub_items = itertools.islice(state_items, len(state_items) // 2)
        torch.save(OrderedDict(sub_items), model_fp)
    with (model_dir / 'cifar_model-2.pth').open('wb') as model_fp:
        sub_items = itertools.islice(state_items, len(state_items) // 2, None)
        torch.save(OrderedDict(sub_items), model_fp)


def load_model():
    model_dir = get_model_dir()
    model = Net()
    with (model_dir / 'cifar_model-1.pth').open('rb') as model_fp:
        model.load_state_dict(torch.load(model_fp), strict=False)
    with (model_dir / 'cifar_model-2.pth').open('rb') as model_fp:
        model.load_state_dict(torch.load(model_fp), strict=False)
    return model


def predict(model, images):
    outputs = model(images)
    _, predicted = torch.max(outputs, 1)
    return predicted, [classes[p] for p in predicted]


def demo_train():
    print('Loading data...')
    trainloader, *_ = get_ds()
    print('Training model...')
    model = train(trainloader)
    print('Saving model...')
    save_model(model)


def demo_inference(sample_ds=False):
    print('Loading data...')
    if sample_ds:
        with (get_ds_dir(sample_ds=True) / 'samples.pt').open('rb') as fp:
            ds_obj = torch.load(fp)
            images, labels = ds_obj['images'], ds_obj['labels']
    else:
        _, testloader, _ = get_ds()
        images, labels = next(iter(testloader))

    print('Loading model...')
    model = load_model()
    print('Inference...')
    print(f'Model predictions: {predict(model, images)}')
    print(f'Labels: {labels}')


def write_sample_ds():
    sample_ds_dir = get_ds_dir(sample_ds=True, create_dir=True)
    with (sample_ds_dir / 'README.txt').open('wt') as fp:
        fp.write('These sample images are retrieved from the following Cifar10 dataset through torchvision:\n')
        fp.write('Learning Multiple Layers of Features from Tiny Images, Alex Krizhevsky, 2009.\n')
    _, testloader, _ = get_ds()
    images, labels = next(iter(testloader))
    with (sample_ds_dir / 'samples.pt').open('wb') as fp:
        torch.save({'images': images, 'labels': labels}, fp)


def main():
    parser = argparse.ArgumentParser()
    op_grp = parser.add_mutually_exclusive_group(required=True)
    op_grp.add_argument('--train', action='store_true')
    op_grp.add_argument('--inference', action='store_true')
    op_grp.add_argument('--inference-samples', action='store_true')

    args = parser.parse_args()
    if args.train:
        demo_train()
        write_sample_ds()
    elif args.inference:
        demo_inference()
    elif args.inference_samples:
        demo_inference(sample_ds=True)


if __name__ == '__main__':
    main()
