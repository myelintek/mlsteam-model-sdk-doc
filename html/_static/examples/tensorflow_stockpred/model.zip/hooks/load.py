"""Loader hook

SDK will do the following:
1. $MLSTEAM_MODEL_DIR is the models directory in package.
2. The hooks directory is added to $PYTHONPATH.
"""
import os
import pathlib

from .common import Model
from .train import load_scaler, load_model


def load(*args, **kwargs):
    os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
    model_dir = pathlib.Path(kwargs['env']['MLSTEAM_MODEL_DIR'])
    scaler = load_scaler(model_dir / 'scaler.pkl')
    model = load_model(model_dir / '1')
    
    return Model(scaler, model, 50)
