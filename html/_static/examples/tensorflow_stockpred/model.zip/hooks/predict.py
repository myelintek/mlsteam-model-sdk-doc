"""Predictor hook"""
import os

import numpy as np

from .common import Model
from .train import extract_x_y


def predict(model: Model, inputs, *args, **kwargs):
    os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
    scaled_data = model.scaler.transform(np.array(inputs)[:,None])
    x_test, _ = extract_x_y(scaled_data, window=model.window, offset=model.window)
    y_scaled = model.model.predict(x_test)
    y = model.scaler.inverse_transform(y_scaled)

    return y
