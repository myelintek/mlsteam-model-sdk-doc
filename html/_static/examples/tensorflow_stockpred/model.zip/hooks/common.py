from collections import namedtuple

Model = namedtuple('Model', ['scaler', 'model', 'window'])
